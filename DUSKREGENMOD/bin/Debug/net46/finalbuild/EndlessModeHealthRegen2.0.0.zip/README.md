 A simple mod that enables regenerating health in endless mode

 If you're below 50HP then you slowly start regenerating until you get back to 50HP again
 every round puts you back at 100HP
