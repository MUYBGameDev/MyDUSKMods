F9 to display/hide the speedometer and toggle what type
F10 to toggle how the speedometer is displayed
F11 for perma-stats
